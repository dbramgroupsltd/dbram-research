/**
 * chat.js — Client-side chat widget logic
 * Loaded on the client dashboard. Requires Socket.io to already be on the page.
 */
function initChat(user) {
  const socket = io();

  const toggle    = document.getElementById('chatToggle');
  const box       = document.getElementById('chatBox');
  const closeBtn  = document.getElementById('chatClose');
  const messages  = document.getElementById('chatMessages');
  const input     = document.getElementById('chatInput');
  const sendBtn   = document.getElementById('chatSend');
  const badge     = document.getElementById('chatBadge');

  let unread = 0;
  let open   = false;

  // Join own room
  socket.emit('join_room', user.id);

  // Load history
  loadHistory();

  // Toggle open/close
  toggle.addEventListener('click', () => {
    open = !open;
    box.classList.toggle('d-none', !open);
    if (open) {
      unread = 0;
      badge.classList.add('d-none');
      scrollToBottom();
      input.focus();
    }
  });
  closeBtn.addEventListener('click', () => {
    open = false;
    box.classList.add('d-none');
  });

  // Send message
  sendBtn.addEventListener('click', sendMessage);
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') sendMessage();
  });

  function sendMessage() {
    const body = input.value.trim();
    if (!body) return;
    socket.emit('send_message', { body, targetUserId: user.id });
    input.value = '';
  }

  // Receive message
  socket.on('new_message', (msg) => {
    appendMessage(msg);
    if (!open && msg.sender === 'support') {
      unread++;
      badge.textContent = unread > 9 ? '9+' : unread;
      badge.classList.remove('d-none');
    }
  });

  async function loadHistory() {
    const res  = await fetch('/api/chat/messages');
    const msgs = await res.json();
    messages.innerHTML = '';
    if (!msgs.length) {
      messages.innerHTML = `<div class="chat-welcome">👋 Hi! How can we help you today?</div>`;
      return;
    }
    msgs.forEach(m => appendMessage(m, false));
    scrollToBottom();
  }

  function appendMessage(msg, scroll = true) {
    const div = document.createElement('div');
    div.className = `chat-msg ${msg.sender === 'client' ? 'mine' : 'theirs'}`;
    div.innerHTML = `
      <div class="msg-bubble">${escHtml(msg.body)}</div>
      <div class="msg-time">${formatTime(msg.created_at)}</div>
    `;
    messages.appendChild(div);
    if (scroll) scrollToBottom();
  }

  function scrollToBottom() {
    messages.scrollTop = messages.scrollHeight;
  }

  function escHtml(str) {
    return str.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  }

  function formatTime(ts) {
    const d = new Date(ts);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  }
}
