'use strict';
require('dotenv').config();

const http        = require('http');
const path        = require('path');
const { randomUUID } = require('crypto');

const express     = require('express');
const session     = require('express-session');
const { Server }  = require('socket.io');
const bcrypt      = require('bcryptjs');
const axios       = require('axios');

// ── Node v22 built-in SQLite ──────────────────────────────────────────────────
const { DatabaseSync } = require('node:sqlite');
const db = new DatabaseSync(path.join(__dirname, 'data.db'));

// ── Bootstrap DB ─────────────────────────────────────────────────────────────
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id        INTEGER PRIMARY KEY AUTOINCREMENT,
    name      TEXT    NOT NULL,
    email     TEXT    NOT NULL UNIQUE,
    password  TEXT    NOT NULL,
    role      TEXT    NOT NULL DEFAULT 'client',
    created_at TEXT   DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS orders (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id       INTEGER NOT NULL,
    title         TEXT    NOT NULL,
    subject       TEXT    NOT NULL,
    deadline      TEXT    NOT NULL,
    pages         INTEGER NOT NULL,
    description   TEXT,
    amount        REAL    NOT NULL,
    status        TEXT    NOT NULL DEFAULT 'pending',
    payment_ref   TEXT,
    created_at    TEXT    DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS messages (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id    INTEGER NOT NULL,
    sender     TEXT    NOT NULL,
    body       TEXT    NOT NULL,
    created_at TEXT    DEFAULT (datetime('now')),
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

// Seed admin account if absent
const adminExists = db.prepare('SELECT id FROM users WHERE email = ?').get('admin@example.com');
if (!adminExists) {
  const hash = bcrypt.hashSync('admin123', 10);
  db.prepare('INSERT INTO users (name,email,password,role) VALUES (?,?,?,?)').run('Admin', 'admin@example.com', hash, 'admin');
  console.log('Admin account created → admin@example.com / admin123');
}

// ── Express app ───────────────────────────────────────────────────────────────
const app    = express();
const server = http.createServer(app);
const io     = new Server(server);

app.set('view engine', 'html');   // we serve raw HTML files
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

const sessionMiddleware = session({
  secret: process.env.SESSION_SECRET || 'dev-secret-change-me',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 }
});
app.use(sessionMiddleware);

// Share session with Socket.io
io.use((socket, next) => sessionMiddleware(socket.request, {}, next));

// ── Auth helpers ─────────────────────────────────────────────────────────────
function requireLogin(req, res, next) {
  if (req.session.userId) return next();
  res.redirect('/login?next=' + encodeURIComponent(req.originalUrl));
}
function requireAdmin(req, res, next) {
  if (req.session.role === 'admin') return next();
  res.status(403).json({ error: 'Forbidden' });
}

// ── Pricing helper ────────────────────────────────────────────────────────────
const PRICE_PER_PAGE = 1500; // ₦1500 per page

// ── Monnify helpers ───────────────────────────────────────────────────────────
async function getMonnifyToken() {
  const credentials = Buffer.from(
    `${process.env.MONNIFY_API_KEY}:${process.env.MONNIFY_SECRET_KEY}`
  ).toString('base64');
  const { data } = await axios.post(
    `${process.env.MONNIFY_BASE_URL}/api/v1/auth/login`,
    {},
    { headers: { Authorization: `Basic ${credentials}` } }
  );
  return data.responseBody.accessToken;
}

async function initMonnifyTransaction({ amount, ref, email, name, description }) {
  const token = await getMonnifyToken();
  const { data } = await axios.post(
    `${process.env.MONNIFY_BASE_URL}/api/v1/merchant/transactions/init-transaction`,
    {
      amount,
      customerName: name,
      customerEmail: email,
      paymentReference: ref,
      paymentDescription: description,
      currencyCode: 'NGN',
      contractCode: process.env.MONNIFY_CONTRACT_CODE,
      redirectUrl: `${process.env.APP_BASE_URL}/payment/verify?ref=${ref}`,
      paymentMethods: ['CARD', 'ACCOUNT_TRANSFER']
    },
    { headers: { Authorization: `Bearer ${token}` } }
  );
  return data.responseBody;
}

async function verifyMonnifyPayment(ref) {
  const token = await getMonnifyToken();
  const encodedRef = encodeURIComponent(ref);
  const { data } = await axios.get(
    `${process.env.MONNIFY_BASE_URL}/api/v1/merchant/transactions/query?paymentReference=${encodedRef}`,
    { headers: { Authorization: `Bearer ${token}` } }
  );
  return data.responseBody;
}

// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTES — Auth
// ═══════════════════════════════════════════════════════════════════════════════
app.get('/', (req, res) => {
  if (req.session.userId) return res.redirect('/dashboard');
  res.redirect('/login');
});

app.get('/login',    (_req, res) => res.sendFile(path.join(__dirname, 'views/login.html')));
app.get('/register', (_req, res) => res.sendFile(path.join(__dirname, 'views/register.html')));

app.post('/api/register', async (req, res) => {
  const { name, email, password } = req.body;
  if (!name || !email || !password)
    return res.json({ ok: false, msg: 'All fields are required.' });
  const existing = db.prepare('SELECT id FROM users WHERE email=?').get(email);
  if (existing) return res.json({ ok: false, msg: 'Email already registered.' });
  const hash = bcrypt.hashSync(password, 10);
  const result = db.prepare('INSERT INTO users (name,email,password) VALUES (?,?,?)').run(name, email, hash);
  req.session.userId = result.lastInsertRowid;
  req.session.name   = name;
  req.session.email  = email;
  req.session.role   = 'client';
  res.json({ ok: true });
});

app.post('/api/login', (req, res) => {
  const { email, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE email=?').get(email);
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.json({ ok: false, msg: 'Invalid email or password.' });
  req.session.userId = user.id;
  req.session.name   = user.name;
  req.session.email  = user.email;
  req.session.role   = user.role;
  res.json({ ok: true, role: user.role });
});

app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});

// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTES — Dashboard
// ═══════════════════════════════════════════════════════════════════════════════
app.get('/dashboard', requireLogin, (req, res) => {
  if (req.session.role === 'admin')
    return res.sendFile(path.join(__dirname, 'views/admin.html'));
  res.sendFile(path.join(__dirname, 'views/dashboard.html'));
});

// ── Orders API ────────────────────────────────────────────────────────────────
app.get('/api/orders', requireLogin, (req, res) => {
  let orders;
  if (req.session.role === 'admin') {
    orders = db.prepare(`
      SELECT o.*, u.name as client_name, u.email as client_email
      FROM orders o JOIN users u ON o.user_id=u.id
      ORDER BY o.created_at DESC
    `).all();
  } else {
    orders = db.prepare('SELECT * FROM orders WHERE user_id=? ORDER BY created_at DESC').all(req.session.userId);
  }
  res.json(orders);
});

app.post('/api/orders', requireLogin, (req, res) => {
  const { title, subject, deadline, pages, description } = req.body;
  if (!title || !subject || !deadline || !pages)
    return res.json({ ok: false, msg: 'All required fields must be filled.' });
  const amount = parseInt(pages) * PRICE_PER_PAGE;
  const result = db.prepare(`
    INSERT INTO orders (user_id,title,subject,deadline,pages,description,amount)
    VALUES (?,?,?,?,?,?,?)
  `).run(req.session.userId, title, subject, deadline, pages, description || '', amount);
  res.json({ ok: true, orderId: result.lastInsertRowid, amount });
});

// Update order status (admin only)
app.patch('/api/orders/:id/status', requireLogin, requireAdmin, (req, res) => {
  const { status } = req.body;
  db.prepare('UPDATE orders SET status=? WHERE id=?').run(status, req.params.id);
  res.json({ ok: true });
});

// ── Session info ──────────────────────────────────────────────────────────────
app.get('/api/me', requireLogin, (req, res) => {
  res.json({
    id:    req.session.userId,
    name:  req.session.name,
    email: req.session.email,
    role:  req.session.role
  });
});

// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTES — Payments
// ═══════════════════════════════════════════════════════════════════════════════
app.post('/api/pay/:orderId', requireLogin, async (req, res) => {
  const order = db.prepare('SELECT * FROM orders WHERE id=? AND user_id=?')
    .get(req.params.orderId, req.session.userId);
  if (!order) return res.json({ ok: false, msg: 'Order not found.' });
  if (order.status !== 'pending') return res.json({ ok: false, msg: 'Order already paid.' });

  const ref = `RW-${order.id}-${randomUUID().split('-')[0].toUpperCase()}`;
  db.prepare('UPDATE orders SET payment_ref=? WHERE id=?').run(ref, order.id);

  try {
    const txn = await initMonnifyTransaction({
      amount: order.amount,
      ref,
      email: req.session.email,
      name:  req.session.name,
      description: `Payment for: ${order.title}`
    });
    res.json({ ok: true, checkoutUrl: txn.checkoutUrl, ref });
  } catch (err) {
    console.error('Monnify init error:', err?.response?.data || err.message);
    res.json({ ok: false, msg: 'Payment gateway error. Check your Monnify credentials.' });
  }
});

// Monnify redirect callback
app.get('/payment/verify', async (req, res) => {
  const { ref, paymentStatus } = req.query;
  if (!ref) return res.redirect('/dashboard?payment=failed');
  try {
    const txn = await verifyMonnifyPayment(ref);
    if (txn && txn.paymentStatus === 'PAID') {
      db.prepare("UPDATE orders SET status='paid' WHERE payment_ref=?").run(ref);
      return res.redirect('/dashboard?payment=success');
    }
    res.redirect('/dashboard?payment=failed');
  } catch (err) {
    console.error('Verify error:', err?.response?.data || err.message);
    res.redirect('/dashboard?payment=failed');
  }
});

// Monnify webhook (server-to-server notification)
app.post('/webhook/monnify', express.json(), (req, res) => {
  // In production: validate HMAC signature here
  const body = req.body;
  if (body?.eventData?.paymentStatus === 'PAID') {
    const ref = body.eventData.paymentReference;
    db.prepare("UPDATE orders SET status='paid' WHERE payment_ref=?").run(ref);
    console.log(`Webhook: order marked paid for ref ${ref}`);
  }
  res.json({ ok: true });
});

// ═══════════════════════════════════════════════════════════════════════════════
//  ROUTES — Chat API
// ═══════════════════════════════════════════════════════════════════════════════
app.get('/api/chat/messages', requireLogin, (req, res) => {
  let rows;
  if (req.session.role === 'admin') {
    const userId = req.query.userId;
    if (!userId) return res.json([]);
    rows = db.prepare('SELECT * FROM messages WHERE user_id=? ORDER BY created_at ASC').all(userId);
  } else {
    rows = db.prepare('SELECT * FROM messages WHERE user_id=? ORDER BY created_at ASC').all(req.session.userId);
  }
  res.json(rows);
});

app.get('/api/chat/threads', requireLogin, requireAdmin, (req, res) => {
  const threads = db.prepare(`
    SELECT u.id, u.name, u.email,
           COUNT(m.id) as msg_count,
           MAX(m.created_at) as last_msg
    FROM users u
    LEFT JOIN messages m ON m.user_id=u.id
    WHERE u.role='client'
    GROUP BY u.id
    ORDER BY last_msg DESC NULLS LAST
  `).all();
  res.json(threads);
});

// ═══════════════════════════════════════════════════════════════════════════════
//  SOCKET.IO — Real-time chat
// ═══════════════════════════════════════════════════════════════════════════════
io.on('connection', (socket) => {
  const sess = socket.request.session;
  if (!sess?.userId) return socket.disconnect(true);

  const userId = sess.userId;
  const role   = sess.role;

  // Each client joins their own room; admin can join any
  socket.on('join_room', (targetUserId) => {
    if (role === 'admin' || targetUserId === userId) {
      socket.join(`chat_${targetUserId}`);
    }
  });

  socket.on('send_message', ({ body, targetUserId }) => {
    const roomUserId = role === 'admin' ? targetUserId : userId;
    if (!body?.trim()) return;
    const sender = role === 'admin' ? 'support' : 'client';
    const stmt = db.prepare('INSERT INTO messages (user_id,sender,body) VALUES (?,?,?)');
    const result = stmt.run(roomUserId, sender, body.trim());
    const msg = db.prepare('SELECT * FROM messages WHERE id=?').get(result.lastInsertRowid);
    io.to(`chat_${roomUserId}`).emit('new_message', msg);
  });

  socket.on('disconnect', () => {});
});

// ─────────────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`\n🚀  ResearchPro is running at http://localhost:${PORT}`);
  console.log(`📧  Admin login: admin@example.com / admin123\n`);
});
